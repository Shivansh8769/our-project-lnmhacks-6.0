# 🤖 ai-object-detection
## 👋 About this project
This is a web AI object detection. You can use it in your web browser. This web application uses the camera of your device to detect objects.

